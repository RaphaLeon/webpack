module.exports = function renderToDOM(element) {
  document.body.append(element);
}
